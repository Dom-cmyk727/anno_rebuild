ANNO 1503 rebuild - preview build (2026-10-16 c, git commit 5281856)
=====================================================================

What this is
------------
A clean-room reimplementation of ANNO 1503 in Rust (project milestone M1.6).
This build is an island VIEWER, not the playable game yet: it reads the
original game files and draws scenarios and islands isometrically
(ground, terrain height, animated sea, rivers and surf, trees, rocks,
buildings, shadows). No gameplay,
no ships or people, no sound.

Requirements
------------
- Windows 10 or 11, 64-bit.
- Your own installed copy of ANNO 1503 (GOG "A.D." edition, 2.0.0.5). The
  rebuild reads the original files at runtime; they are NOT included here.
  The install folder is the one that contains Anlagen.dat.

Start
-----
Double-click start-viewer.bat and enter your ANNO 1503 install folder when
asked (or pass it: start-viewer.bat "C:\GOG Games\ANNO 1503").
It opens the first single-player scenario (Scenes\0200Single\Single_01.sze).
Another scenario or island:
  start-viewer.bat "<game folder>" "<game folder>\Scenes\...\file.sze"
  (island templates: Scenes\Islands\<climate>\*.scp)

Controls
--------
  drag (left mouse), arrow keys or WASD  pan
  mouse wheel, + / -                     zoom (3 levels)
  Esc or Q                               quit
  Space                                  pause / resume the water animation
The first frame at each zoom level is rendered on all CPU cores; it can take
a moment on large scenarios.

Command-line tools (bin\)
-------------------------
  anno1503.exe --view <file.sze|file.scp> [--game-dir <dir>] [--group 0|1|2] [--png out.png]
      --png renders the whole scene to an image without opening a window.
  anno-extract.exe view <game dir> <file> <island index> <out.png> [<zoom group>]
  anno-extract.exe figuren|anlagen|tex|insel ...   export original graphics to PNG
  anno-dump.exe tex|figuren|anlagen|insel|colors|chunks ...   inspect file formats
  Run any tool without arguments for its usage.

Known limitations of this preview
---------------------------------
- Built by cross-compiling on macOS; not yet run on a Windows machine. Please
  report any start-up problem with the exact error text.
- Only water is animated so far (sea, rivers, surf); other animations, ships,
  people and the original's terrain lighting are missing. River channels can
  look blocky (approximation of the original's open-water drawing). Draw order is a painter's approximation of the original's
  depth buffer, so rare overlap errors are expected.
- Details and evidence: docs/PLAN.md, docs/render/iso.md and
  docs/open-questions.md in the source.

Source
------
anno1503-source.zip is a snapshot of the repository at the commit above
(code, specs, tests; no game files). Build from source:
  rustup (stable), then: cargo build --release
  tests with game files: set ANNO1503_GAME_DIR=<game folder> & cargo test --workspace
